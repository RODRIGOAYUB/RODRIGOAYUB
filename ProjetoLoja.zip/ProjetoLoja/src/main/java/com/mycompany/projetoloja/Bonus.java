package com.mycompany.projetoloja;

public interface Bonus {
    
    public double calcularBonus();
    
}
