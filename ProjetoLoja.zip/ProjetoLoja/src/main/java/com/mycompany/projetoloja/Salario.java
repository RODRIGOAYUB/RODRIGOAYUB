package com.mycompany.projetoloja;

public interface Salario {
    
    public double calcularSalario();
    
}
